import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  phone:number=1234567890;

  email:string="phse2demo@gmail.com";
  
  constructor() { }

  ngOnInit(): void {
  }

}
