import { Component, OnInit } from '@angular/core';
import { Product } from '../models/product';
import { ProductService } from '../services/product.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-admin-portal',
  templateUrl: './admin-portal.component.html',
  styleUrls: ['./admin-portal.component.css'],
})
export class AdminPortalComponent implements OnInit {

  productList: Product[] = []

  x:any = {};

  num:number=0;

  msg:string=' ';

  num2:number=0;

  num3:number=0;

  num4:number=0;

  num5:number=0;

  num6:number=0;

  msg4:string=' ';

  constructor(private ps: ProductService,private modalService: NgbModal) { }

  ngOnInit(): void {
  }

  viewAllProducts()
  {
    this.num=1;
    this.productList = this.ps.getProducts();
  }

  addItem(id:number)
  {
    var index= Number(this.productList.findIndex(x=>x.id==id));
    if(index>=0)
    {
      this.msg=`The food item with ID ${id} already present. Try New`;
      this.num3=2;
    }
    else
    {
      this.productList.push(this.x);
      this.msg=`New Fodd item is added....Count of Items: ${this.productList.length}`;
      this.num3=1;
    }
  }

  editItem(id:number, ch:number)
  {

    switch(ch)
    {

      case 1:
        var index= Number(this.productList.findIndex(x=>x.id==id));
        this.productList[index].id=this.x.id;
        break;


      case 2:
        var index= Number(this.productList.findIndex(x=>x.id==id));
        this.productList[index].name=this.x.name;
        break;

      case 3:
        var index= Number(this.productList.findIndex(x=>x.id==id));
        this.productList[index].desc=this.x.desc;
        break;

      case 4:
        var index= Number(this.productList.findIndex(x=>x.id==id));
        this.productList[index].cat=this.x.cat;
        break;

      case 5:
        var index= Number(this.productList.findIndex(x=>x.id==id));
        this.productList[index].price=this.x.price;
        break;

      case 6:
        var index= Number(this.productList.findIndex(x=>x.id==id));
        this.productList[index].imgUrl=this.x.imgUrl;
        break;
      
    }
    
  }

  deleteById(id:number)
  {
    if(confirm("Are you sure?"))
    {
      var index= Number(this.productList.findIndex(x=>x.id==id));
      this.productList.splice(index,1);
      this.msg=`Count of people: ${this.productList.length}`;
    }
  }

  getAllProducts(){
    return this.num;
  }

  numberRet()
  {
    return this.num3;
  }

  makeRow()
  {
    this.num2=1;
  }

  haveRow()
  {
    return this.num2;
  }
  
  makerow(id:number)
  {
    this.num4=id;
    this.num5=1;
  }

  haverow()
  {
    return this.num5;
  }

  returnEdit()
  {
    return this.num4;
  }

  numValue(n:number)
  {
    this.num6=n;
  }

  numValueRet()
  {
    return this.num6;
  }

}
