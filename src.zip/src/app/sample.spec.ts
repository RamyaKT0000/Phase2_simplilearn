import { Sample } from './sample';

describe('Sample', () => {
  it('should create an instance', () => {
    expect(new Sample()).toBeTruthy();
  });
});
