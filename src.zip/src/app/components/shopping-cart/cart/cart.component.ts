import { Component, OnInit } from '@angular/core'
import { MessengerService } from 'src/app/services/messenger.service';
import { Product } from 'src/app/models/product';
import {IMessage} from 'src/app/sample';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})


export class CartComponent implements OnInit {

  cartItems:IMessage[] = [];

  cartTotal = 0;
  
  billingName?:string;

  msgs:string=' ';

  val:boolean=true;

  msg2:string=' ';

  num2:number=0;
  
  msg3:string=' ';

  display():boolean
  {
    if(this.billingName?.length!=0)
    {
      this.msgs = `Hello ${this.billingName}`;
      this.val=true;
    }
    else
    {
      this.msgs = `Hello`;
      this.val=false;
    }
    return this.val;
  }

  constructor(private msg:MessengerService, private modalService: NgbModal,) { }

  ngOnInit(){

    this.msg.getMsg().subscribe((product:any)=>{   
      this.addProductToCart(product);
    })
    
  }

  addProductToCart(product:Product)
  {
    let productExists = false


    for(let i in this.cartItems){
      if(this.cartItems[i].productId===product.id)
      {
        this.cartItems[i].qty++;
        productExists=true;
        break
      }
    }

    if(!productExists)
    {
      this.cartItems.push({
        productId:product.id,
        name: product.name,
        qty:1,
        price:product.price
        })
    }

    this.cartTotal=0;

    this.cartItems.forEach(item=>{
      this.cartTotal += (item.qty * item.price)
    })
  }

  closeResult = '';

  open(content:any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  getStatus()
  {
    return this.msg3;
  }

  SetNext()
  {
    this.msg3="Your Order Status: "
    if(this.cartTotal>0)
    {
      this.msg2="Your Order is Successful";
      this.num2=1;
    }
    else
    {
      this.msg2="You dont have any food items to order";
      this.num2=2;
    }
    
  }

  getNext()
  {
    return this.num2;
  }

}



  