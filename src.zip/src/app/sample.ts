export interface IMessage {
    productId:number
    name:string;
    qty:number;
    price:number;
  }