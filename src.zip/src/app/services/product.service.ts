import { Injectable } from '@angular/core';
import { Product } from '../models/product';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

 products:Product[] = [
    new Product(1, "Rava Idli", "Classic South India recipe. Taste really good", 30, "/assets/rava-idli.jpg","BreakFast"),
    new Product(2, "Masala Dosa", "Crispy South India recipe. Taste really cool", 70, "/assets/Masala-Dosa.jpg","BreakFast"),
    new Product(3, "Poori", "Delicious and great tasted. oil free item available", 47, "/assets/poori.jpg", "BreakFast"),
    new Product(4, "Veg Biriyani", "Wonderful south indian rice item, good for health", 124, "/assets/veg-biriyani.jpg","Rice"),
    new Product(5, "Curd Rice", "Healthy and tasty curd rice, helps for digestion", 65, "/assets/curd-rice.jpg","Rice"),
    new Product(6, "South Indian Thali", "Classic South Indian thali. Taste really good", 150, "/assets/thali.jpg","Rice"),
    new Product(7, "Apple Juice", "Super tasty apple juice. Really cool", 50, "/assets/apple.jpg","Juices"),
    new Product(8, "Mango Juice", "Ultimate taste and flavour", 60, "/assets/mango.jpg","Juices"),
    new Product(9, "Lemon Juice", "Healthy drink for everyone", 37, "/assets/lemon.jpg","Juices")

 ]
  
  constructor() { }

  getProducts():Product[]{
    return this.products;
  }

}
